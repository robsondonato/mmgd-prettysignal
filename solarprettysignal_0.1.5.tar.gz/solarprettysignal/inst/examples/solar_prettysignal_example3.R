library(shiny)
library(openxlsx)
library(plotly)

# Define the path to the example template file
name_file <- "example_data"
ext <- ".xlsx"
file_path <- system.file("demo", paste0(name_file, ext), package = "solarprettysignal")

ui <- fluidPage(
  fluidRow(column(1),
           column(10, titlePanel("Solar Pretty Signal - Shiny App")),
           column(1)),

  fluidRow(column(1),
           column(10, sidebarPanel(
             fileInput("file", "Choose XLSX File", accept = c(".xlsx")),
             div(style = "border: 1px solid #ddd; display: flex; gap: 10px;",
                div(style = "border: 1px solid #ddd;",
                  checkboxInput("midnight", "Midnight is first hour", TRUE),
                ),
               div(style = ".linkdow {border: 1px solid #ddd; align-items: center; justify-content: center;}",
                  downloadLink("downloadTemplate", "Download template here",class = "linkdow"),
               ),
             ),
             downloadButton("downloadData", "Download Processed Data"),
           )),
           column(1)),

  fluidRow(column(1),
           column(10, div(
             style = "border: 2px solid #ccc; padding: 20px; text-align: center;",
             plotlyOutput("distPlot"),
             conditionalPanel(
               condition = "output.plotReady == false",
               h4("Gráfico será plotado aqui")
             )
           )),
           column(1))
)

server <- function(input, output, session) {
  data <- reactive({
    req(input$file)
    read.xlsx(input$file$datapath, sheet = 1)
  })

  processed_data <- reactive({
    req(data())
    solar_prettysignal(data(), input$midnight)
  })

  output$distPlot <- renderPlotly({
    req(processed_data())
    df <- processed_data()
    p <- plot_ly() %>%
      add_lines(x = ~as.POSIXct(df$Time), y = ~df$Original_data, name = 'Original', line = list(color = 'blue')) %>%
      add_lines(x = ~as.POSIXct(df$Time), y = ~df$Filtered_data, name = 'Filtered', line = list(color = 'red')) %>%
      layout(
        title = "Original and Filtered Signal by Solar Pretty Signal",
        xaxis = list(title = "Time"),
        yaxis = list(title = "MW"),
        legend = list(x = 0.9, y = 1, orientation = 'v')
      )
    p
  })

  output$plotReady <- reactive({
    is.null(processed_data()) == FALSE
  })

  outputOptions(output, "plotReady", suspendWhenHidden = FALSE)

  output$downloadData <- downloadHandler(
    filename = function() {
      paste0("processed_data_", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      write.xlsx(processed_data(), file, sheetName = "results", rowNames = FALSE)
    }
  )

  output$downloadTemplate <- downloadHandler(
    filename = function() {
      paste0(name_file, ext)
    },
    content = function(file) {
      file.copy(file_path, file)
    }
  )
}

shinyApp(ui = ui, server = server)

