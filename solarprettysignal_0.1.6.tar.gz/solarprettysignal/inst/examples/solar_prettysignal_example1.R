library(shiny)
library(shinyjs)
library(openxlsx)
library(plotly)
library(solarprettysignal)

name_file <- "example_data"
ext <- ".xlsx"
file_path <- system.file("examples", paste0(name_file, ext), package = "solarprettysignal")

ui <- fluidPage(

  div(class = "mainbody",
      useShinyjs(),
      tags$head(tags$link(rel = "stylesheet", href = "style2.css", type = "text/css")),

      div(class = "titulo_tema",
          h1("Solar Pretty Signal", HTML("<sub class=\"versao-label\">v 0.1.5</sub>")),
          "Transforming noisy signals into clear and continuous curves."
          ),

      div(class = "inputbox",
          div(class = "all_inputs",
              div(class = "listelements",
                  div(class = "texto",
                    downloadLink("downloadTemplate", "(Download Template Here)"),
                  ),
                  fileInput("file",buttonLabel = "Search...",placeholder = "Select files",label = "",
                            accept = c(".xlsx")),

              )
          ),
          div(class = "outputs",
              div(class = "listelements",
                  downloadButton("downloadData", class = "baixar-pdf-btn", "Download Processed Data"),
              )
          )
      ),



      div(class = "grafico",
          div(class = "graphfilters",
            checkboxInput("midnight", "Midnight is first hour", FALSE),
            checkboxInput("peakadjustement", "Adjust to Peak", FALSE),
          ),
          plotlyOutput("distPlot"),
      ),

      div(class = "feedback",
          "In case of any questions, suggestions, or compliments, please contact me. I would be delighted to receive your feedback.",

      div(class = "perfil",

          div(class = "member-pic",
            img(src = "me.png", class = "avatar"),
          ),

          div(class = "section-member-info",
            div(class = "member-info",
              h4("Robson Donato"),
              span("An Electrical Engineer materializing knowledge"),
            ),

            div(class= "social",
                a(href = "mailto:engenheirodonato.ons@gmail.com", icon("envelope"), target = "_blank"),
                a(href = "https://www.linkedin.com/in/robsondonato/", icon("linkedin"), target = "_blank"),
                a(href = "https://github.com/robsondonato/", icon("github"), target = "_blank")
            )
          ),
      )
      ),

  )
)

server <- function(input, output, session) {

    shinyjs::disable("downloadData")

    data <- reactive({
      req(input$file)
      read.xlsx(input$file$datapath, sheet = 1)
    })

    processed_data <- reactive({
      req(data())
      solar_prettysignal(data(), input$midnight, input$peakadjustement)
    })

    initial_data <- data.frame(
      Time = seq(from = as.POSIXct("2023-01-01 00:00"), by = "hour", length.out = 24),
      Value = rep(0, 24)
    )

    output$distPlot <- renderPlotly({
      plot_ly(data = initial_data, x = ~Time, y = ~Value, type = 'scatter', mode = 'lines', line = list(color = 'rgba(0,0,0,0.01)')) %>%
        layout(
          title = "Your data will be plotted here",
          xaxis = list(title = "Time"),
          yaxis = list(title = "Data"),
          showlegend = FALSE
        )
    })

    observeEvent(processed_data(), {
      req(processed_data())
      shinyjs::enable("downloadData")
      df <- processed_data()
      output$distPlot <- renderPlotly({
        plot_ly() %>%
          add_lines(x = ~as.POSIXct(df$Time), y = ~df$Original_data, name = 'Original', line = list(color = '#3C91E6')) %>%
          add_lines(x = ~as.POSIXct(df$Time), y = ~df$Filtered_data, name = 'Filtered', line = list(color = '#342E37')) %>%
          layout(
            title = "Original and Filtered Signal by Solar Pretty Signal",
            xaxis = list(title = "Time"),
            yaxis = list(title = "Data"),
            legend = list(x = 0.9, y = 1, orientation = 'v')
          )
      })
    })

        output$downloadData <- downloadHandler(
          filename = function() {
            paste0("processed_data_", Sys.Date(), ".xlsx")
          },
          content = function(file) {
            write.xlsx(processed_data(), file, sheetName = "results", rowNames = FALSE)
          }
        )

        output$downloadTemplate <- downloadHandler(
          filename = function() {
            paste0(name_file, ext)
          },
          content = function(file) {
            file.copy(file_path, file)
          }
        )
}

shinyApp(ui = ui, server = server)

